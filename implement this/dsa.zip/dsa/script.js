/* ============================================
   Smart Campus DSA - JavaScript
   Manual Data Structure Implementations
   ============================================ */

// ============================================
// LINKED LIST - Student Management
// ============================================
class Node {
    constructor(data) {
        this.data = data;
        this.next = null;
    }
}

class LinkedList {
    constructor() {
        this.head = null;
        this.size = 0;
    }

    // Insert at the end
    insert(data) {
        const newNode = new Node(data);
        if (!this.head) {
            this.head = newNode;
        } else {
            let current = this.head;
            while (current.next) {
                current = current.next;
            }
            current.next = newNode;
        }
        this.size++;
        return true;
    }

    // Delete by ID
    deleteById(id) {
        if (!this.head) return null;

        if (this.head.data.id === id) {
            const deleted = this.head.data;
            this.head = this.head.next;
            this.size--;
            return deleted;
        }

        let current = this.head;
        while (current.next && current.next.data.id !== id) {
            current = current.next;
        }

        if (current.next) {
            const deleted = current.next.data;
            current.next = current.next.next;
            this.size--;
            return deleted;
        }
        return null;
    }

    // Convert to array for display
    toArray() {
        const result = [];
        let current = this.head;
        while (current) {
            result.push(current.data);
            current = current.next;
        }
        return result;
    }

    clear() {
        this.head = null;
        this.size = 0;
    }
}

// Initialize linked list
const studentList = new LinkedList();

function addStudent() {
    const name = document.getElementById('student-name').value.trim();
    const id = document.getElementById('student-id').value.trim().toUpperCase();
    
    if (!name || !id) {
        logOperation('ll-log', '⚠️ Please enter both name and ID');
        return;
    }

    studentList.insert({ name, id });
    renderLinkedList();
    logOperation('ll-log', `✓ Added: ${name} (${id}) → O(1) at tail`);
    
    document.getElementById('student-name').value = '';
    document.getElementById('student-id').value = '';
}

function deleteStudent() {
    const id = document.getElementById('student-id').value.trim().toUpperCase();
    if (!id) {
        logOperation('ll-log', '⚠️ Enter ID to delete');
        return;
    }

    const deleted = studentList.deleteById(id);
    if (deleted) {
        renderLinkedList();
        logOperation('ll-log', `✓ Deleted: ${deleted.name} (${id}) → O(1) deletion`);
    } else {
        logOperation('ll-log', `✗ Student ${id} not found`);
    }
    document.getElementById('student-id').value = '';
}

function clearLinkedList() {
    studentList.clear();
    renderLinkedList();
    logOperation('ll-log', '✓ List cleared');
}

function renderLinkedList() {
    const container = document.getElementById('linked-list-viz');
    const students = studentList.toArray();

    if (students.length === 0) {
        container.innerHTML = '<div class="ll-empty-state">Click "Add Student" to begin</div>';
        return;
    }

    let html = '';
    for (let i = 0; i < students.length; i++) {
        html += `
            <div class="ll-node">
                <div class="ll-node-box">
                    <div class="ll-node-name">${students[i].name}</div>
                    <div class="ll-node-id">${students[i].id}</div>
                </div>
            </div>
            <span class="ll-arrow">→</span>
        `;
    }
    html += '<span class="ll-null">NULL</span>';
    container.innerHTML = html;
}

// ============================================
// ARRAY - Course Database
// ============================================
class CourseDatabase {
    constructor(maxSize) {
        this.courses = [];
        this.maxSize = maxSize;
        this.count = 0;
    }

    add(course) {
        if (this.count >= this.maxSize) {
            return { success: false, message: 'Database full (fixed size)' };
        }
        this.courses[this.count] = course;
        this.count++;
        return { success: true, index: this.count - 1 };
    }

    search(code) {
        for (let i = 0; i < this.count; i++) {
            if (this.courses[i].code === code) {
                return { found: true, index: i, course: this.courses[i] };
            }
        }
        return { found: false };
    }

    getAll() {
        return this.courses.slice(0, this.count);
    }
}

const courseDB = new CourseDatabase(10);

// Pre-populate with sample data
courseDB.add({ code: 'CS101', name: 'Data Structures', credits: 4, room: 'LH-01' });
courseDB.add({ code: 'CS102', name: 'Algorithms', credits: 3, room: 'LH-02' });
courseDB.add({ code: 'MA101', name: 'Linear Algebra', credits: 3, room: 'LH-03' });

function addCourse() {
    const code = document.getElementById('course-code').value.trim().toUpperCase();
    const name = document.getElementById('course-name').value.trim();
    const credits = parseInt(document.getElementById('course-credits').value) || 0;
    const room = document.getElementById('course-room').value.trim().toUpperCase();

    if (!code || !name || !credits || !room) {
        logOperation('array-log', '⚠️ Fill all fields');
        return;
    }

    const result = courseDB.add({ code, name, credits, room });
    if (result.success) {
        renderCourseTable();
        logOperation('array-log', `✓ Added at index ${result.index} → O(1) insertion`);
        clearCourseInputs();
    } else {
        logOperation('array-log', `✗ ${result.message}`);
    }
}

function searchCourse() {
    const code = document.getElementById('course-code').value.trim().toUpperCase();
    if (!code) {
        logOperation('array-log', '⚠️ Enter course code');
        return;
    }

    const result = courseDB.search(code);
    renderCourseTable(result.found ? result.index : -1);
    
    if (result.found) {
        logOperation('array-log', `✓ Found "${result.course.name}" at index ${result.index}`);
    } else {
        logOperation('array-log', `✗ Course ${code} not found`);
    }
}

function clearCourseInputs() {
    document.getElementById('course-code').value = '';
    document.getElementById('course-name').value = '';
    document.getElementById('course-credits').value = '';
    document.getElementById('course-room').value = '';
}

function renderCourseTable(highlightIndex = -1) {
    const tbody = document.getElementById('course-tbody');
    const courses = courseDB.getAll();

    let html = '';
    for (let i = 0; i < courses.length; i++) {
        const rowClass = i === highlightIndex ? 'highlight-row' : '';
        html += `
            <tr class="${rowClass}">
                <td>${i}</td>
                <td>${courses[i].code}</td>
                <td>${courses[i].name}</td>
                <td>${courses[i].credits}</td>
                <td>${courses[i].room}</td>
            </tr>
        `;
    }
    tbody.innerHTML = html;
}

// ============================================
// HASH TABLE - Search System
// ============================================
class HashTable {
    constructor(size) {
        this.size = size;
        this.buckets = [];
        for (let i = 0; i < size; i++) {
            this.buckets[i] = [];
        }
    }

    // Custom hash function - sum of char codes mod size
    hash(key) {
        let sum = 0;
        for (let i = 0; i < key.length; i++) {
            sum += key.charCodeAt(i);
        }
        return sum % this.size;
    }

    insert(key, value) {
        const index = this.hash(key);
        // Check for existing key
        for (let i = 0; i < this.buckets[index].length; i++) {
            if (this.buckets[index][i].key === key) {
                this.buckets[index][i].value = value;
                return { index, updated: true };
            }
        }
        this.buckets[index].push({ key, value });
        return { index, updated: false };
    }

    search(key) {
        const index = this.hash(key);
        for (let i = 0; i < this.buckets[index].length; i++) {
            if (this.buckets[index][i].key === key) {
                return { found: true, index, value: this.buckets[index][i].value };
            }
        }
        return { found: false, index };
    }

    clear() {
        for (let i = 0; i < this.size; i++) {
            this.buckets[i] = [];
        }
    }
}

const hashTable = new HashTable(7);

function hashInsert() {
    const key = document.getElementById('hash-key').value.trim().toUpperCase();
    const value = document.getElementById('hash-value').value.trim();

    if (!key || !value) {
        logOperation('hash-log', '⚠️ Enter both ID and name');
        return;
    }

    const result = hashTable.insert(key, value);
    updateHashDisplay(key, result.index);
    renderHashTable(result.index);
    
    const action = result.updated ? 'Updated' : 'Inserted';
    logOperation('hash-log', `✓ ${action}: hash("${key}") = ${result.index}`);

    document.getElementById('hash-key').value = '';
    document.getElementById('hash-value').value = '';
}

function hashSearch() {
    const key = document.getElementById('hash-key').value.trim().toUpperCase();
    if (!key) {
        logOperation('hash-log', '⚠️ Enter ID to search');
        return;
    }

    const result = hashTable.search(key);
    updateHashDisplay(key, result.index);
    renderHashTable(result.index, result.found ? key : null);

    if (result.found) {
        logOperation('hash-log', `✓ Found "${result.value}" at bucket ${result.index} → O(1)`);
    } else {
        logOperation('hash-log', `✗ Not found. Checked bucket ${result.index}`);
    }
}

function clearHashTable() {
    hashTable.clear();
    renderHashTable();
    updateHashDisplay('-', '-');
    logOperation('hash-log', '✓ Hash table cleared');
}

function updateHashDisplay(key, index) {
    document.getElementById('hash-key-display').textContent = key;
    document.getElementById('hash-index-display').textContent = index;
}

function renderHashTable(activeIndex = -1, foundKey = null) {
    const container = document.getElementById('hash-table-viz');
    let html = '';

    for (let i = 0; i < hashTable.size; i++) {
        const isActive = i === activeIndex;
        html += `<div class="hash-bucket ${isActive ? 'active' : ''}">
            <div class="bucket-index">[${i}]</div>
            <div class="bucket-items">`;
        
        for (const item of hashTable.buckets[i]) {
            const isFound = foundKey && item.key === foundKey;
            html += `<div class="bucket-item ${isFound ? 'found' : ''}">${item.key}: ${item.value}</div>`;
        }
        
        html += '</div></div>';
    }
    container.innerHTML = html;
}

// ============================================
// MAX HEAP - Priority Queue (Complaints)
// ============================================
class MaxHeap {
    constructor() {
        this.heap = [];
    }

    getParentIndex(i) { return Math.floor((i - 1) / 2); }
    getLeftChildIndex(i) { return 2 * i + 1; }
    getRightChildIndex(i) { return 2 * i + 2; }

    swap(i, j) {
        const temp = this.heap[i];
        this.heap[i] = this.heap[j];
        this.heap[j] = temp;
    }

    insert(item) {
        this.heap.push(item);
        this.heapifyUp(this.heap.length - 1);
    }

    heapifyUp(index) {
        let parentIndex = this.getParentIndex(index);
        while (index > 0 && this.heap[index].priority > this.heap[parentIndex].priority) {
            this.swap(index, parentIndex);
            index = parentIndex;
            parentIndex = this.getParentIndex(index);
        }
    }

    extractMax() {
        if (this.heap.length === 0) return null;
        if (this.heap.length === 1) return this.heap.pop();

        const max = this.heap[0];
        this.heap[0] = this.heap.pop();
        this.heapifyDown(0);
        return max;
    }

    heapifyDown(index) {
        let largest = index;
        const left = this.getLeftChildIndex(index);
        const right = this.getRightChildIndex(index);

        if (left < this.heap.length && this.heap[left].priority > this.heap[largest].priority) {
            largest = left;
        }
        if (right < this.heap.length && this.heap[right].priority > this.heap[largest].priority) {
            largest = right;
        }

        if (largest !== index) {
            this.swap(index, largest);
            this.heapifyDown(largest);
        }
    }

    peek() {
        return this.heap.length > 0 ? this.heap[0] : null;
    }

    size() {
        return this.heap.length;
    }

    clear() {
        this.heap = [];
    }

    toArray() {
        return [...this.heap];
    }
}

const complaintHeap = new MaxHeap();

function addComplaint() {
    const text = document.getElementById('complaint-text').value.trim();
    const priority = parseInt(document.getElementById('complaint-priority').value) || 0;

    if (!text || priority < 1 || priority > 10) {
        logOperation('heap-log', '⚠️ Enter complaint and priority (1-10)');
        return;
    }

    complaintHeap.insert({ text, priority });
    renderHeap();
    logOperation('heap-log', `✓ Added: "${text}" (P=${priority}) → heapifyUp O(log n)`);

    document.getElementById('complaint-text').value = '';
    document.getElementById('complaint-priority').value = '';
}

function processComplaint() {
    const max = complaintHeap.extractMax();
    if (max) {
        renderHeap();
        logOperation('heap-log', `✓ Processed: "${max.text}" (P=${max.priority}) → extractMax O(log n)`);
    } else {
        logOperation('heap-log', '⚠️ No complaints to process');
    }
}

function clearHeap() {
    complaintHeap.clear();
    renderHeap();
    logOperation('heap-log', '✓ Heap cleared');
}

function renderHeap() {
    const container = document.getElementById('heap-viz');
    const items = complaintHeap.toArray();

    if (items.length === 0) {
        container.innerHTML = '<div class="heap-empty-state">Add complaints to see heap</div>';
        return;
    }

    // Build tree visualization by levels
    let html = '<div class="heap-tree">';
    let level = 0;
    let levelStart = 0;

    while (levelStart < items.length) {
        const levelSize = Math.pow(2, level);
        html += '<div class="heap-level">';
        
        for (let i = levelStart; i < levelStart + levelSize && i < items.length; i++) {
            const item = items[i];
            let priorityClass = 'priority-low';
            if (item.priority >= 10) priorityClass = 'priority-high';
            else if (item.priority >= 7) priorityClass = 'priority-medium';

            html += `
                <div class="heap-node ${priorityClass}">
                    <span class="heap-node-priority">${item.priority}</span>
                    <span class="heap-node-text">${item.text}</span>
                </div>
            `;
        }
        
        html += '</div>';
        levelStart += levelSize;
        level++;
    }
    html += '</div>';
    container.innerHTML = html;
}

// ============================================
// QUEUE - Task Scheduling
// ============================================
class Queue {
    constructor() {
        this.items = [];
        this.front = 0;
        this.rear = 0;
    }

    enqueue(item) {
        this.items[this.rear] = item;
        this.rear++;
    }

    dequeue() {
        if (this.isEmpty()) return null;
        const item = this.items[this.front];
        delete this.items[this.front];
        this.front++;
        return item;
    }

    peek() {
        return this.items[this.front];
    }

    isEmpty() {
        return this.front === this.rear;
    }

    size() {
        return this.rear - this.front;
    }

    clear() {
        this.items = [];
        this.front = 0;
        this.rear = 0;
    }

    toArray() {
        const result = [];
        for (let i = this.front; i < this.rear; i++) {
            result.push(this.items[i]);
        }
        return result;
    }
}

const taskQueue = new Queue();

function enqueueTask() {
    const name = document.getElementById('task-name').value.trim();
    if (!name) {
        logOperation('queue-log', '⚠️ Enter task name');
        return;
    }

    taskQueue.enqueue(name);
    renderQueue();
    logOperation('queue-log', `✓ Enqueued: "${name}" → O(1)`);
    document.getElementById('task-name').value = '';
}

function dequeueTask() {
    const task = taskQueue.dequeue();
    if (task) {
        renderQueue();
        logOperation('queue-log', `✓ Dequeued: "${task}" → FIFO O(1)`);
    } else {
        logOperation('queue-log', '⚠️ Queue is empty');
    }
}

function clearQueue() {
    taskQueue.clear();
    renderQueue();
    logOperation('queue-log', '✓ Queue cleared');
}

function renderQueue() {
    const container = document.getElementById('queue-viz');
    const items = taskQueue.toArray();

    if (items.length === 0) {
        container.innerHTML = '<div class="queue-empty-state">Queue is empty</div>';
        return;
    }

    let html = '';
    for (const item of items) {
        html += `<div class="queue-item">${item}</div>`;
    }
    container.innerHTML = html;
}

// ============================================
// STACK - Undo/Redo System
// ============================================
class Stack {
    constructor() {
        this.items = [];
        this.top = -1;
    }

    push(item) {
        this.top++;
        this.items[this.top] = item;
    }

    pop() {
        if (this.isEmpty()) return null;
        const item = this.items[this.top];
        this.items.length = this.top;
        this.top--;
        return item;
    }

    peek() {
        return this.items[this.top];
    }

    isEmpty() {
        return this.top === -1;
    }

    size() {
        return this.top + 1;
    }

    clear() {
        this.items = [];
        this.top = -1;
    }

    toArray() {
        return [...this.items];
    }
}

const undoStack = new Stack();
const redoStack = new Stack();

function pushAction() {
    const action = document.getElementById('action-name').value.trim();
    if (!action) {
        logOperation('stack-log', '⚠️ Enter action name');
        return;
    }

    undoStack.push(action);
    redoStack.clear(); // Clear redo when new action
    renderStacks();
    logOperation('stack-log', `✓ Action: "${action}" → push O(1)`);
    document.getElementById('action-name').value = '';
}

function undoAction() {
    const action = undoStack.pop();
    if (action) {
        redoStack.push(action);
        renderStacks();
        logOperation('stack-log', `✓ Undo: "${action}" → LIFO pop O(1)`);
    } else {
        logOperation('stack-log', '⚠️ Nothing to undo');
    }
}

function redoAction() {
    const action = redoStack.pop();
    if (action) {
        undoStack.push(action);
        renderStacks();
        logOperation('stack-log', `✓ Redo: "${action}" → pop+push O(1)`);
    } else {
        logOperation('stack-log', '⚠️ Nothing to redo');
    }
}

function clearStacks() {
    undoStack.clear();
    redoStack.clear();
    renderStacks();
    logOperation('stack-log', '✓ Stacks cleared');
}

function renderStacks() {
    const undoContainer = document.getElementById('stack-viz');
    const redoContainer = document.getElementById('redo-stack-viz');

    // Render undo stack (reversed - top first)
    const undoItems = undoStack.toArray().reverse();
    if (undoItems.length === 0) {
        undoContainer.innerHTML = '<div class="stack-empty-state">Stack is empty</div>';
    } else {
        undoContainer.innerHTML = undoItems.map(item => 
            `<div class="stack-item">${item}</div>`
        ).join('');
    }

    // Render redo stack
    const redoItems = redoStack.toArray().reverse();
    if (redoItems.length === 0) {
        redoContainer.innerHTML = '<div class="stack-empty-state">Empty</div>';
    } else {
        redoContainer.innerHTML = redoItems.map(item => 
            `<div class="stack-item">${item}</div>`
        ).join('');
    }
}

// ============================================
// GRAPH - Campus Navigation (BFS/DFS)
// ============================================
class Graph {
    constructor() {
        this.adjacencyList = {};
        this.nodes = {};
    }

    addNode(id, data) {
        if (!this.adjacencyList[id]) {
            this.adjacencyList[id] = [];
            this.nodes[id] = data;
        }
    }

    addEdge(node1, node2) {
        if (this.adjacencyList[node1] && this.adjacencyList[node2]) {
            if (!this.adjacencyList[node1].includes(node2)) {
                this.adjacencyList[node1].push(node2);
            }
            if (!this.adjacencyList[node2].includes(node1)) {
                this.adjacencyList[node2].push(node1);
            }
        }
    }

    // BFS - Shortest path
    bfs(start, end) {
        const visited = {};
        const parent = {};
        const queue = [start];
        visited[start] = true;
        parent[start] = null;

        while (queue.length > 0) {
            const current = queue.shift();
            
            if (current === end) {
                return this.buildPath(parent, end);
            }

            for (const neighbor of this.adjacencyList[current]) {
                if (!visited[neighbor]) {
                    visited[neighbor] = true;
                    parent[neighbor] = current;
                    queue.push(neighbor);
                }
            }
        }
        return null;
    }

    // DFS - Exploration
    dfs(start, end) {
        const visited = {};
        const parent = {};
        const stack = [start];
        parent[start] = null;

        while (stack.length > 0) {
            const current = stack.pop();
            
            if (!visited[current]) {
                visited[current] = true;
                
                if (current === end) {
                    return this.buildPath(parent, end);
                }

                for (const neighbor of this.adjacencyList[current]) {
                    if (!visited[neighbor]) {
                        parent[neighbor] = current;
                        stack.push(neighbor);
                    }
                }
            }
        }
        return null;
    }

    buildPath(parent, end) {
        const path = [];
        let current = end;
        while (current !== null) {
            path.unshift(current);
            current = parent[current];
        }
        return path;
    }

    getNodes() {
        return Object.keys(this.adjacencyList);
    }
}

// Campus graph setup
const campusGraph = new Graph();
let currentAlgorithm = 'bfs';

// Add campus locations with positions
const locations = [
    { id: 'hostel', icon: '🏠', label: 'Hostel', x: 80, y: 180 },
    { id: 'canteen', icon: '🍽️', label: 'Canteen', x: 180, y: 80 },
    { id: 'library', icon: '📚', label: 'Library', x: 320, y: 80 },
    { id: 'lab', icon: '💻', label: 'Lab', x: 420, y: 180 },
    { id: 'ground', icon: '⚽', label: 'Ground', x: 180, y: 280 },
    { id: 'admin', icon: '🏢', label: 'Admin', x: 320, y: 280 }
];

function initGraph() {
    // Add nodes
    for (const loc of locations) {
        campusGraph.addNode(loc.id, loc);
    }

    // Add edges
    campusGraph.addEdge('hostel', 'canteen');
    campusGraph.addEdge('hostel', 'ground');
    campusGraph.addEdge('canteen', 'library');
    campusGraph.addEdge('canteen', 'ground');
    campusGraph.addEdge('library', 'lab');
    campusGraph.addEdge('library', 'admin');
    campusGraph.addEdge('lab', 'admin');
    campusGraph.addEdge('ground', 'admin');

    renderGraph();
    populateNodeSelects();
}

function setAlgorithm(algo) {
    currentAlgorithm = algo;
    document.getElementById('bfs-btn').classList.toggle('active', algo === 'bfs');
    document.getElementById('dfs-btn').classList.toggle('active', algo === 'dfs');
    resetGraph();
}

function findPath() {
    const startId = document.getElementById('start-node').value;
    const endId = document.getElementById('end-node').value;

    if (!startId || !endId) {
        logOperation('graph-log', '⚠️ Select start and end nodes');
        return;
    }

    if (startId === endId) {
        logOperation('graph-log', '⚠️ Start and end must be different');
        return;
    }

    const path = currentAlgorithm === 'bfs' 
        ? campusGraph.bfs(startId, endId)
        : campusGraph.dfs(startId, endId);

    if (path) {
        highlightPath(path);
        const algoName = currentAlgorithm.toUpperCase();
        logOperation('graph-log', `✓ ${algoName} Path: ${path.join(' → ')}`);
        document.getElementById('path-display').textContent = `Path: ${path.map(id => campusGraph.nodes[id].label).join(' → ')}`;
    } else {
        logOperation('graph-log', '✗ No path found');
    }
}

function resetGraph() {
    document.querySelectorAll('.graph-node').forEach(n => {
        n.classList.remove('visited', 'path-node');
    });
    document.querySelectorAll('.graph-edge').forEach(e => {
        e.classList.remove('path-edge');
    });
    document.getElementById('path-display').textContent = 'Select start and end nodes to find path';
}

function highlightPath(path) {
    resetGraph();
    
    // Highlight nodes
    for (const nodeId of path) {
        const nodeEl = document.querySelector(`[data-node="${nodeId}"]`);
        if (nodeEl) nodeEl.classList.add('path-node');
    }

    // Highlight edges
    for (let i = 0; i < path.length - 1; i++) {
        const edgeEl = document.querySelector(`[data-edge="${path[i]}-${path[i+1]}"], [data-edge="${path[i+1]}-${path[i]}"]`);
        if (edgeEl) edgeEl.classList.add('path-edge');
    }
}

function renderGraph() {
    const svg = document.getElementById('graph-svg');
    const nodesContainer = document.getElementById('graph-nodes');

    // Draw edges
    let edgesHTML = '';
    const drawnEdges = {};
    
    for (const nodeId of Object.keys(campusGraph.adjacencyList)) {
        for (const neighborId of campusGraph.adjacencyList[nodeId]) {
            const edgeKey = [nodeId, neighborId].sort().join('-');
            if (!drawnEdges[edgeKey]) {
                const node1 = campusGraph.nodes[nodeId];
                const node2 = campusGraph.nodes[neighborId];
                edgesHTML += `<line class="graph-edge" data-edge="${edgeKey}" x1="${node1.x}" y1="${node1.y}" x2="${node2.x}" y2="${node2.y}"/>`;
                drawnEdges[edgeKey] = true;
            }
        }
    }
    svg.innerHTML = edgesHTML;

    // Draw nodes
    let nodesHTML = '';
    for (const loc of locations) {
        nodesHTML += `
            <div class="graph-node" data-node="${loc.id}" style="left: ${loc.x}px; top: ${loc.y}px;">
                <span class="node-icon">${loc.icon}</span>
                <span class="node-label">${loc.label}</span>
            </div>
        `;
    }
    nodesContainer.innerHTML = nodesHTML;
}

function populateNodeSelects() {
    const startSelect = document.getElementById('start-node');
    const endSelect = document.getElementById('end-node');

    let optionsHTML = '<option value="">Select...</option>';
    for (const loc of locations) {
        optionsHTML += `<option value="${loc.id}">${loc.label}</option>`;
    }

    startSelect.innerHTML = optionsHTML;
    endSelect.innerHTML = optionsHTML;
}

// ============================================
// BST - Resource Timeline
// ============================================
class TreeNode {
    constructor(time, resource) {
        this.time = time;
        this.resource = resource;
        this.left = null;
        this.right = null;
    }
}

class BST {
    constructor() {
        this.root = null;
    }

    insert(time, resource) {
        const newNode = new TreeNode(time, resource);
        
        if (!this.root) {
            this.root = newNode;
            return { success: true, conflict: false };
        }

        return this._insertNode(this.root, newNode);
    }

    _insertNode(node, newNode) {
        if (newNode.time === node.time) {
            return { success: false, conflict: true, existing: node.resource };
        }

        if (newNode.time < node.time) {
            if (!node.left) {
                node.left = newNode;
                return { success: true, conflict: false };
            }
            return this._insertNode(node.left, newNode);
        } else {
            if (!node.right) {
                node.right = newNode;
                return { success: true, conflict: false };
            }
            return this._insertNode(node.right, newNode);
        }
    }

    search(time) {
        return this._searchNode(this.root, time);
    }

    _searchNode(node, time) {
        if (!node) return { found: false };
        if (time === node.time) return { found: true, resource: node.resource };
        if (time < node.time) return this._searchNode(node.left, time);
        return this._searchNode(node.right, time);
    }

    inorder() {
        const result = [];
        this._inorderTraverse(this.root, result);
        return result;
    }

    _inorderTraverse(node, result) {
        if (node) {
            this._inorderTraverse(node.left, result);
            result.push({ time: node.time, resource: node.resource });
            this._inorderTraverse(node.right, result);
        }
    }

    clear() {
        this.root = null;
    }

    // Get levels for visualization
    getLevels() {
        if (!this.root) return [];
        
        const levels = [];
        const queue = [{ node: this.root, level: 0 }];

        while (queue.length > 0) {
            const { node, level } = queue.shift();
            
            if (!levels[level]) levels[level] = [];
            levels[level].push({ time: node.time, resource: node.resource });

            if (node.left) queue.push({ node: node.left, level: level + 1 });
            if (node.right) queue.push({ node: node.right, level: level + 1 });
        }

        return levels;
    }
}

const bookingBST = new BST();

function addBooking() {
    const time = parseInt(document.getElementById('booking-time').value);
    const resource = document.getElementById('booking-resource').value.trim().toUpperCase();

    if (!time || time < 9 || time > 18 || !resource) {
        logOperation('bst-log', '⚠️ Enter time (9-18) and resource');
        return;
    }

    const result = bookingBST.insert(time, resource);
    renderBST();
    renderTimeline();

    if (result.success) {
        logOperation('bst-log', `✓ Booked ${resource} at ${time}:00 → O(log n)`);
    } else {
        logOperation('bst-log', `✗ Conflict! ${time}:00 already booked (${result.existing})`);
    }

    document.getElementById('booking-time').value = '';
    document.getElementById('booking-resource').value = '';
}

function searchBooking() {
    const time = parseInt(document.getElementById('booking-time').value);
    
    if (!time || time < 9 || time > 18) {
        logOperation('bst-log', '⚠️ Enter time (9-18)');
        return;
    }

    const result = bookingBST.search(time);
    if (result.found) {
        logOperation('bst-log', `✓ ${time}:00 is booked (${result.resource})`);
    } else {
        logOperation('bst-log', `✓ ${time}:00 is available`);
    }
}

function clearBST() {
    bookingBST.clear();
    renderBST();
    renderTimeline();
    logOperation('bst-log', '✓ BST cleared');
}

function renderBST() {
    const container = document.getElementById('bst-viz');
    const levels = bookingBST.getLevels();

    if (levels.length === 0) {
        container.innerHTML = '<div class="bst-empty-state">Add bookings to see BST</div>';
        return;
    }

    let html = '<div class="bst-tree">';
    for (const level of levels) {
        html += '<div class="bst-level">';
        for (const node of level) {
            html += `
                <div class="bst-node">
                    <span class="bst-node-time">${node.time}:00</span>
                    <span class="bst-node-resource">${node.resource}</span>
                </div>
            `;
        }
        html += '</div>';
    }
    html += '</div>';
    container.innerHTML = html;
}

function renderTimeline() {
    const container = document.getElementById('timeline-viz');
    const sortedBookings = bookingBST.inorder();

    if (sortedBookings.length === 0) {
        container.innerHTML = '<span class="timeline-empty">No bookings yet</span>';
        return;
    }

    container.innerHTML = sortedBookings.map(b => 
        `<span class="timeline-slot">${b.time}:00 - ${b.resource}</span>`
    ).join('');
}

// ============================================
// CODE TABS
// ============================================
const codeContent = {
    linkedlist: {
        code: `class Node {
    constructor(data) {
        this.data = data;
        this.next = null;
    }
}

class LinkedList {
    constructor() {
        this.head = null;
        this.size = 0;
    }

    // Insert at the end - O(n), O(1) if tail pointer maintained
    insert(data) {
        const newNode = new Node(data);
        if (!this.head) {
            this.head = newNode;
        } else {
            let current = this.head;
            while (current.next) {
                current = current.next;
            }
            current.next = newNode;
        }
        this.size++;
    }

    // Delete by ID - O(n) search + O(1) deletion
    deleteById(id) {
        if (!this.head) return null;

        if (this.head.data.id === id) {
            const deleted = this.head.data;
            this.head = this.head.next;
            this.size--;
            return deleted;
        }

        let current = this.head;
        while (current.next && current.next.data.id !== id) {
            current = current.next;
        }

        if (current.next) {
            const deleted = current.next.data;
            current.next = current.next.next;
            this.size--;
            return deleted;
        }
        return null;
    }
}`,
        explanation: `A Linked List is a linear data structure where elements are stored in nodes, and each node points to the next one. Unlike arrays, elements are not stored in contiguous memory locations.

<strong>Key Operations:</strong>
• <strong>Insertion:</strong> Create new node, update pointers. O(1) at head, O(n) at tail without tail pointer.
• <strong>Deletion:</strong> Find node, update previous node's pointer to skip it. O(1) once node is found.
• <strong>Traversal:</strong> Follow next pointers from head to desired node. O(n).

<strong>Why use for Student Records?</strong>
Student records require frequent additions and removals. With arrays, deleting a student means shifting all subsequent elements. Linked lists only update two pointers – much faster!`,
        complexity: 'Insert: O(1) at head | Delete: O(1) after finding | Search: O(n)'
    },
    hashtable: {
        code: `class HashTable {
    constructor(size) {
        this.size = size;
        this.buckets = [];
        for (let i = 0; i < size; i++) {
            this.buckets[i] = []; // Chaining for collision handling
        }
    }

    // Custom hash function - sum of ASCII values mod size
    hash(key) {
        let sum = 0;
        for (let i = 0; i < key.length; i++) {
            sum += key.charCodeAt(i);
        }
        return sum % this.size;
    }

    // Insert key-value pair - O(1) average
    insert(key, value) {
        const index = this.hash(key);
        
        // Check for existing key (update)
        for (let i = 0; i < this.buckets[index].length; i++) {
            if (this.buckets[index][i].key === key) {
                this.buckets[index][i].value = value;
                return { index, updated: true };
            }
        }
        
        // Add new entry
        this.buckets[index].push({ key, value });
        return { index, updated: false };
    }

    // Search by key - O(1) average
    search(key) {
        const index = this.hash(key);
        for (let i = 0; i < this.buckets[index].length; i++) {
            if (this.buckets[index][i].key === key) {
                return { found: true, index, value: this.buckets[index][i].value };
            }
        }
        return { found: false, index };
    }
}`,
        explanation: `A Hash Table is a data structure that maps keys to values using a hash function. The hash function converts a key into an array index, allowing for near-instant lookups.

<strong>How it works:</strong>
1. <strong>Hash Function:</strong> Converts key (student ID) to array index
2. <strong>Collision Handling:</strong> When two keys hash to the same index, we use "chaining" - storing multiple items in a linked list at that bucket
3. <strong>Search:</strong> Hash the key, go directly to that bucket, search within bucket

<strong>Why use for Student Search?</strong>
With 10,000 students, linear search takes up to 10,000 comparisons. Hash tables average O(1) - just one computation to find any student!`,
        complexity: 'Average: O(1) for insert/search | Worst: O(n) with bad hash'
    },
    heap: {
        code: `class MaxHeap {
    constructor() {
        this.heap = [];
    }

    getParentIndex(i) { return Math.floor((i - 1) / 2); }
    getLeftChildIndex(i) { return 2 * i + 1; }
    getRightChildIndex(i) { return 2 * i + 2; }

    swap(i, j) {
        const temp = this.heap[i];
        this.heap[i] = this.heap[j];
        this.heap[j] = temp;
    }

    // Insert and bubble up - O(log n)
    insert(item) {
        this.heap.push(item);
        this.heapifyUp(this.heap.length - 1);
    }

    heapifyUp(index) {
        let parentIndex = this.getParentIndex(index);
        while (index > 0 && 
               this.heap[index].priority > this.heap[parentIndex].priority) {
            this.swap(index, parentIndex);
            index = parentIndex;
            parentIndex = this.getParentIndex(index);
        }
    }

    // Extract max (root) and heapify down - O(log n)
    extractMax() {
        if (this.heap.length === 0) return null;
        if (this.heap.length === 1) return this.heap.pop();

        const max = this.heap[0];
        this.heap[0] = this.heap.pop();
        this.heapifyDown(0);
        return max;
    }

    heapifyDown(index) {
        let largest = index;
        const left = this.getLeftChildIndex(index);
        const right = this.getRightChildIndex(index);

        if (left < this.heap.length && 
            this.heap[left].priority > this.heap[largest].priority) {
            largest = left;
        }
        if (right < this.heap.length && 
            this.heap[right].priority > this.heap[largest].priority) {
            largest = right;
        }

        if (largest !== index) {
            this.swap(index, largest);
            this.heapifyDown(largest);
        }
    }
}`,
        explanation: `A Max Heap is a complete binary tree where every parent node has a value greater than or equal to its children. The maximum element is always at the root.

<strong>Heap Property:</strong>
• Parent ≥ Children (Max Heap)
• Complete binary tree (filled level by level, left to right)
• Stored as array: parent at i, children at 2i+1 and 2i+2

<strong>Key Operations:</strong>
• <strong>Insert:</strong> Add at end, bubble up to maintain heap property
• <strong>Extract Max:</strong> Remove root, move last element to root, bubble down

<strong>Why use for Complaints?</strong>
Emergency complaints (fire, medical) must be handled first. A max heap ensures the highest priority item is always accessible in O(1), and insertion/extraction are O(log n).`,
        complexity: 'Insert: O(log n) | Extract Max: O(log n) | Peek Max: O(1)'
    },
    queue: {
        code: `class Queue {
    constructor() {
        this.items = [];
        this.front = 0;
        this.rear = 0;
    }

    // Add to rear - O(1)
    enqueue(item) {
        this.items[this.rear] = item;
        this.rear++;
    }

    // Remove from front - O(1)
    dequeue() {
        if (this.isEmpty()) return null;
        
        const item = this.items[this.front];
        delete this.items[this.front];
        this.front++;
        return item;
    }

    // View front element - O(1)
    peek() {
        return this.items[this.front];
    }

    isEmpty() {
        return this.front === this.rear;
    }

    size() {
        return this.rear - this.front;
    }
}`,
        explanation: `A Queue is a First-In-First-Out (FIFO) data structure. Elements are added at the rear and removed from the front, just like a real-world queue.

<strong>FIFO Principle:</strong>
• First person in line gets served first
• New arrivals join at the back
• Fair and predictable ordering

<strong>Key Operations:</strong>
• <strong>Enqueue:</strong> Add element to rear
• <strong>Dequeue:</strong> Remove element from front
• <strong>Peek:</strong> View front element without removing

<strong>Why use for Scheduling?</strong>
Lab bookings and event requests should be processed in order of arrival. A queue naturally maintains this "first come, first served" fairness.`,
        complexity: 'Enqueue: O(1) | Dequeue: O(1) | Peek: O(1)'
    },
    stack: {
        code: `class Stack {
    constructor() {
        this.items = [];
        this.top = -1;
    }

    // Add to top - O(1)
    push(item) {
        this.top++;
        this.items[this.top] = item;
    }

    // Remove from top - O(1)
    pop() {
        if (this.isEmpty()) return null;
        
        const item = this.items[this.top];
        this.items.length = this.top;
        this.top--;
        return item;
    }

    // View top element - O(1)
    peek() {
        return this.items[this.top];
    }

    isEmpty() {
        return this.top === -1;
    }

    size() {
        return this.top + 1;
    }
}

// Undo/Redo System using two stacks
function undo() {
    if (undoStack.isEmpty()) return null;
    const action = undoStack.pop();
    redoStack.push(action);
    return action;
}

function redo() {
    if (redoStack.isEmpty()) return null;
    const action = redoStack.pop();
    undoStack.push(action);
    return action;
}`,
        explanation: `A Stack is a Last-In-First-Out (LIFO) data structure. Elements are added and removed from the same end (top), like a stack of plates.

<strong>LIFO Principle:</strong>
• Last item added is the first to be removed
• Only the top element is accessible
• Perfect for tracking history/state

<strong>Key Operations:</strong>
• <strong>Push:</strong> Add element to top
• <strong>Pop:</strong> Remove element from top
• <strong>Peek:</strong> View top element without removing

<strong>Why use for Undo/Redo?</strong>
When you undo, you want to reverse the most recent action. Stacks naturally maintain this order. Two stacks (undo + redo) create a complete history system.`,
        complexity: 'Push: O(1) | Pop: O(1) | Peek: O(1)'
    },
    graph: {
        code: `class Graph {
    constructor() {
        this.adjacencyList = {};
    }

    addNode(id) {
        if (!this.adjacencyList[id]) {
            this.adjacencyList[id] = [];
        }
    }

    addEdge(node1, node2) {
        // Undirected graph - add both directions
        this.adjacencyList[node1].push(node2);
        this.adjacencyList[node2].push(node1);
    }

    // BFS - Shortest path in unweighted graph
    bfs(start, end) {
        const visited = {};
        const parent = {};
        const queue = [start];
        
        visited[start] = true;
        parent[start] = null;

        while (queue.length > 0) {
            const current = queue.shift();
            
            if (current === end) {
                return this.buildPath(parent, end);
            }

            for (const neighbor of this.adjacencyList[current]) {
                if (!visited[neighbor]) {
                    visited[neighbor] = true;
                    parent[neighbor] = current;
                    queue.push(neighbor);
                }
            }
        }
        return null;
    }

    // DFS - Exploration/full traversal
    dfs(start, end) {
        const visited = {};
        const parent = {};
        const stack = [start];
        parent[start] = null;

        while (stack.length > 0) {
            const current = stack.pop();
            
            if (!visited[current]) {
                visited[current] = true;
                
                if (current === end) {
                    return this.buildPath(parent, end);
                }

                for (const neighbor of this.adjacencyList[current]) {
                    if (!visited[neighbor]) {
                        parent[neighbor] = current;
                        stack.push(neighbor);
                    }
                }
            }
        }
        return null;
    }

    buildPath(parent, end) {
        const path = [];
        let current = end;
        while (current !== null) {
            path.unshift(current);
            current = parent[current];
        }
        return path;
    }
}`,
        explanation: `A Graph is a data structure consisting of nodes (vertices) connected by edges. It's perfect for modeling real-world networks like campus maps, social networks, and road systems.

<strong>BFS (Breadth-First Search):</strong>
• Explores level by level (all neighbors first)
• Uses a Queue (FIFO)
• Guarantees shortest path in unweighted graphs

<strong>DFS (Depth-First Search):</strong>
• Explores as deep as possible before backtracking
• Uses a Stack (LIFO)
• Good for maze solving, topological sorting

<strong>Why use for Campus Navigation?</strong>
Campus buildings (nodes) connected by paths (edges) form a natural graph. BFS finds the shortest walking route, while DFS can explore all reachable locations.`,
        complexity: 'BFS/DFS: O(V + E) where V=vertices, E=edges'
    },
    bst: {
        code: `class TreeNode {
    constructor(time, resource) {
        this.time = time;
        this.resource = resource;
        this.left = null;
        this.right = null;
    }
}

class BST {
    constructor() {
        this.root = null;
    }

    // Insert new booking - O(log n) average
    insert(time, resource) {
        const newNode = new TreeNode(time, resource);
        
        if (!this.root) {
            this.root = newNode;
            return { success: true };
        }

        return this._insertNode(this.root, newNode);
    }

    _insertNode(node, newNode) {
        // Conflict detection
        if (newNode.time === node.time) {
            return { success: false, conflict: true, existing: node.resource };
        }

        if (newNode.time < node.time) {
            if (!node.left) {
                node.left = newNode;
                return { success: true };
            }
            return this._insertNode(node.left, newNode);
        } else {
            if (!node.right) {
                node.right = newNode;
                return { success: true };
            }
            return this._insertNode(node.right, newNode);
        }
    }

    // In-order traversal returns sorted timeline
    inorder() {
        const result = [];
        this._inorderTraverse(this.root, result);
        return result;
    }

    _inorderTraverse(node, result) {
        if (node) {
            this._inorderTraverse(node.left, result);
            result.push({ time: node.time, resource: node.resource });
            this._inorderTraverse(node.right, result);
        }
    }
}`,
        explanation: `A Binary Search Tree (BST) is a binary tree where for each node, all left descendants have smaller values and all right descendants have larger values.

<strong>BST Property:</strong>
• Left subtree < Node < Right subtree
• In-order traversal gives sorted sequence
• Efficient searching by eliminating half the tree each step

<strong>Key Operations:</strong>
• <strong>Insert:</strong> Compare and go left/right until empty spot found
• <strong>Search:</strong> Compare and go left/right until found or null
• <strong>In-order:</strong> Left → Root → Right (gives sorted order)

<strong>Why use for Resource Timeline?</strong>
Bookings need to be sorted by time. BST maintains sorted order automatically, detects conflicts (duplicate times), and in-order traversal produces a perfect timeline!`,
        complexity: 'Average: O(log n) | Worst (skewed): O(n)'
    }
};

function showCodeTab(tab) {
    // Update button states
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');

    // Show content
    const content = codeContent[tab];
    document.getElementById('code-tab-content').innerHTML = `
        <div class="code-block">
            <div class="code-section">
                <h4>💻 Implementation</h4>
                <pre><code>${content.code}</code></pre>
            </div>
            <div class="explanation-section">
                <h4>📖 Explanation</h4>
                <p>${content.explanation}</p>
                <div class="complexity-badge">⏱️ ${content.complexity}</div>
            </div>
        </div>
    `;
}

// ============================================
// UTILITY FUNCTIONS
// ============================================
function logOperation(logId, message) {
    const log = document.getElementById(logId);
    log.textContent = message;
}

// ============================================
// NAVIGATION
// ============================================
function initNavigation() {
    const navToggle = document.getElementById('nav-toggle');
    const navMenu = document.querySelector('.nav-menu');

    navToggle.addEventListener('click', () => {
        navMenu.classList.toggle('active');
    });

    // Close menu on link click
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', () => {
            navMenu.classList.remove('active');
        });
    });

    // Smooth scroll
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
}

// ============================================
// INITIALIZATION
// ============================================
document.addEventListener('DOMContentLoaded', () => {
    initNavigation();
    initGraph();
    renderLinkedList();
    renderCourseTable();
    renderHashTable();
    renderHeap();
    renderQueue();
    renderStacks();
    renderBST();
    renderTimeline();
    showCodeTab('linkedlist');
});
